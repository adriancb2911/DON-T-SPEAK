const nombre = prompt("Como te llamas ");
const edad = Number(prompt("Que edad tienes?"));
let mas10 = edad + 10;
let mas25 = edad + 25;
let mas50 = edad + 50;
document.getElementById("mensaje1").textContent = nombre + ", dentro de 10 años tendras " + mas10 + " años" ;
document.getElementById("mensaje2").textContent = nombre + ", dentro de 25 años tendras " + mas25 + " años" ;
document.getElementById("mensaje3").textContent = nombre + ", sdentro de 50 años tendras " + mas50 + " años" ;