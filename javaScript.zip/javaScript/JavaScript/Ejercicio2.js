let energia = 100;
let despegue = 20;
let escudos = 15
let panel = 30;
let salto = 40;
let generador = 10;
energia -= despegue;
energia += panel;
energia -= salto;
console.log(energia);
