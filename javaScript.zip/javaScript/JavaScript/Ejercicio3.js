const precioPorKg = 18;
const tasaEspacial = 12;
const nombre = prompt("Como te llamas")
const destino = prompt("Donde quieres llevar el paquete ")
const paquetes = Number(prompt("Cuantos paquetes quieres llevar" ))
const kilos = Number(prompt("Cuantos kilos quieres"))


console.log("=====SPACE DELIVERY=====");
console.log("Cliente: " + nombre );
console.log("Destino: " +  destino)
console.log("Paquetes: " + paquetes);
console.log("Peso total: " + kilos * paquetes );
console.log("trasnporte: " + (kilos * paquetes) * 18);
console.log("Tasas espaciales: " + paquetes * 12);
console.log("TOTAL: " + (((kilos * paquetes) * 18) + (paquetes * 12)));






