let banda1 = "linkin park";
let banda2 = "green day";
let banda3 = "skillet";
let banda4 = "gorillaz";
let banda5 = "three days grace";

let precio1 = 8;
let precio2 = 10;
let precio3 = 9;
let precio4 = 12;
let precio5 = 15;


const bandafav = prompt("Que banda quieres escuchar")
const numEntradas = Number(prompt("Cuantas entradas quieres"))
const dineroDisponible = Number(prompt("Cuanto dinero puedes gastar"))
function calcularPrecio() {
    if (bandafav.toLowerCase() === banda1){
        document.getElementById("precioEntradas").textContent = "Precio total de las entradas: " + (precio1 * numEntradas);
        document.getElementById("total").textContent = "Dinero total disponible: " + dineroDisponible;
        document.getElementById("restante").textContent = "Dinero restante despues de comprar entradas: " + (dineroDisponible - (precio1 * numEntradas));
        const nombre1 = prompt("Como te llamas")
        document.getElementById("nombre").textContent = "Asistente: " + nombre1;
        document.getElementById("artista").textContent = "Artista favorito: " + bandafav;
        document.getElementById("entradas").textContent = "Entrasdas: " + numEntradas;
        document.getElementById("total2").textContent = "Dinero total disponible: " + dineroDisponible;
        document.getElementById("restante2").textContent = "Dinero restante despues de comprar entradas: " + (dineroDisponible - (precio1 * numEntradas));

    }
    else if(bandafav.toLowerCase() === banda2){
        document.getElementById("precioEntradas").textContent = "Precio total de las entradas: " + (precio2 * numEntradas);
        document.getElementById("total").textContent = "Dinero total disponible: " + dineroDisponible;
        document.getElementById("restante").textContent = "Dinero restante despues de comprar entradas: " + (dineroDisponible - (precio2 * numEntradas));
        const nombre2 = prompt("Como te llamas")
        document.getElementById("nombre").textContent = "Asistente: " + nombre2;
        document.getElementById("artista").textContent = "Artista favorito: " + bandafav;
        document.getElementById("entradas").textContent = "Entrasdas: " + numEntradas;
        document.getElementById("total2").textContent = "Dinero total disponible: " + dineroDisponible;
        document.getElementById("restante2").textContent = "Dinero restante despues de comprar entradas: " + (dineroDisponible - (precio1 * numEntradas));
    }
    else if(bandafav.toLowerCase() === banda3){
        document.getElementById("precioEntradas").textContent = "Precio total de las entradas: " + (precio3 * numEntradas);
        document.getElementById("total").textContent = "Dinero total disponible: " + dineroDisponible;
        document.getElementById("restante").textContent = "Dinero restante despues de comprar entradas: " + (dineroDisponible - (precio3 * numEntradas));
        const nombre3 = prompt("Como te llamas")
        document.getElementById("nombre").textContent = "Asistente: " + nombre3;
        document.getElementById("artista").textContent ="Artista favorito: " + bandafav;
        document.getElementById("entradas").textContent = "Entrasdas: " + numEntradas;
        document.getElementById("total2").textContent = "Dinero total disponible: " + dineroDisponible;
        document.getElementById("restante2").textContent = "Dinero restante despues de comprar entradas: " + (dineroDisponible - (precio1 * numEntradas));
    }
    else if(bandafav.toLowerCase() === banda4){
        document.getElementById("precioEntradas").textContent = "Precio total de las entradas: " + (precio4 * numEntradas);
        document.getElementById("total").textContent = "Dinero total disponible: " + dineroDisponible;
        document.getElementById("restante").textContent = "Dinero restante despues de comprar entradas: " + (dineroDisponible - (precio4 * numEntradas));
        const nombre4 = prompt("Como te llamas")
        document.getElementById("nombre").textContent = "Asistente: " + nombre4;
        document.getElementById("artista").textContent ="Artista favorito: " + bandafav;
        document.getElementById("entradas").textContent = "Entrasdas: " + numEntradas;
        document.getElementById("total2").textContent = "Dinero total disponible: " + dineroDisponible;
        document.getElementById("restante2").textContent = "Dinero restante despues de comprar entradas: " + (dineroDisponible - (precio1 * numEntradas));
    }
    else if(bandafav.toLowerCase() === banda5){
        document.getElementById("precioEntradas").textContent = "Precio total de las entradas: " + (precio5 * numEntradas);
        document.getElementById("total").textContent = "Dinero total disponible: " + dineroDisponible;
        document.getElementById("restante").textContent = "Dinero restante despues de comprar entradas: " + (dineroDisponible - (precio5 * numEntradas));
        const nombre5 = prompt("Como te llamas")
        document.getElementById("nombre").textContent = "Asistente: " + nombre5;
        document.getElementById("artista").textContent ="Artista favorito: " + bandafav;
        document.getElementById("entradas").textContent = "Entrasdas: " + numEntradas;
        document.getElementById("total2").textContent = "Dinero total disponible: " + dineroDisponible;
        document.getElementById("restante2").textContent = "Dinero restante despues de comprar entradas: " + (dineroDisponible - (precio1 * numEntradas));
    }
    }
    
