let vida = 50;
let sigilo = 50;
let monstruos = 3;
let salida = false;
let cuchillo = false;
let secreto = false;
let linterna = false;
let vidaLinterna = 50;
let mapa = false;

function iniciarJuego() {
    while (vida > 0 || salida == false) {
        alert("Estás en un Búnker...");
        alert("Acabas de despertar...");
        alert("No sabes dónde estás, pero... ¿Qué es eso?");
        alert("Escuchas un chillido horrible, muy agudo, parece ser de algo que nunca has oído.");
        alert("Solo una idea viene a tu mente... Tengo que salir de aquí.");

        const opcion = Number(prompt("Delante de ti ves 3 objetos:\n 1. Unas vendas \n 2. Un cuchillo \n 3. Una linterna \n ¿Cuál eliges?"));
        
        switch (opcion) {
            case 1:
                alert("Agarraste las vendas del suelo, aunque no estaban muy limpias, te hacen un apaño. (+20 de vida)");
                vida += 20;
                break;
            case 2:
                alert("Con el cuchillo estarás más seguro, ¿no?");
                cuchillo = true;
                break;
            case 3:
                alert("Agarras la linterna. Cuando la enciendes, parpadea un poco; parece que le quedan pocas pilas, pero te puede servir.");
                linterna = true;
                break;
            default:
                alert("Elige una de las opciones que te doy. ¡Rápido, que la criatura se acerca!");
                continue; // Vuelve a pedir objeto si la opción no es válida
        }

        // Esta parte ahora se ejecuta tras elegir un objeto válido
        alert("Después de elegir objeto sales de esa habitación.");
        alert("Según sales ves todo en muy mal estado.");
        alert("Paredes llenas de humedad, todo derruido y lo peor de todo... ¿por qué hay tanta sangre?");

        const opcion2 = Number(prompt("Ante ti se vislumbran 3 caminos:\n 1. El ala norte \n 2. El ala este \n 3. El ala oeste \n ¿A dónde deseas ir?"));
        
        switch (opcion2) {
            case 1: 
                alert("Sigues el camino del ala norte, avanzas por el pasillo.");
                alert("Ruidos se escuchan de fondo, escuchas a lo lejos el mismo chillido que antes... parece que te has alejado, ¿no?");
                const opcion2_1 = Number(prompt("Según sigues por el pasillo escuchas un ruido provenir de una puerta cerrada:\n 1. Ignorarlo y seguir por el camino \n 2. Abrir la puerta \n ¿Qué decides?"));
                switch(opcion2_1){
                    case 1: 
                    alert("Sigues por el camino, todo parece tranquilo, pero algo no cuadra");
                    alert("notas el suelo ¿Pegajoso?...")
                    alert("*Sonido de metal caerse*");
                    if (linterna == false){
                        const opcion2_1_1 = Number(prompt("Tienes que hacer algo\n 1. Preguntas ¿Quien hay ahi? \n 2. Te quedas callado esperando que no pase nada"))
                    }
                    else{
                        const opcion2_1_1 = Number(prompt("Tienes que hacer algo\n 1. Preguntas ¿Quien hay ahi? \n 2. Te quedas callado esperando que no pase nada \n 3. Alumbras con la linterna"))
                    }
                    switch(opcion2_1_1){
                        case 1: 
                            alert("Escuchas como algo se acerca a ti y...");
                            alert("Un corte aparece en tu brazo (-20 de vida)");
                            vida -= 20;
                            alert("no tenias que hacer eso, aprende de esas cosas");
                            if (cuchillo == true) {
                                const opcion2_1_2 = Number(prompt("La criatura después de dañarte el brazo, se empieza a acercar a ti \n 1. Le intentas pedir que se valla \n 2. Te quedas quieto y rezas a que no pase nada \n Le clavas el cuchillo "));
                            
                            }
                            break
                    }
                    
                }
                break;
            default:
                alert("Elige una opción, puede que esto sea vital para tu escape.");
                break;
        }
        break; 
    }
}